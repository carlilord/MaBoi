﻿using System;

namespace GoogleHashCode
{
    public class Ride
    {
        public int Id { get; set; }

        public int RowStart { get; set; }

        public int ColumnStart { get; set; }

        public int RowFinish { get; set; }

        public int ColumnFinish { get; set; }

        public int EarliestStart { get; set; }

        public int LatestFinish { get; set; }

        public bool IsPickedUp { get; set; }


        public int GetDistance()
        {
            return Math.Abs(RowStart - RowFinish) + Math.Abs(ColumnStart - ColumnFinish);
        }

        
    }
}