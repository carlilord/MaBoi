﻿using System;
namespace GoogleHashCode
{
    public class Problem
    {
        private int x;

        public Problem()
        {
            var s = FileHelper.ReadInput();
        }
    }
}
