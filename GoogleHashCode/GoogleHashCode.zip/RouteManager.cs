﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GoogleHashCode
{
    public class RouteManager
    {

        public int RowCount { get; set; }

        public int ColumnCount { get; set; }
    
        public int VehiclesCount { get; set; }

        public int RidesCount { get; set; }

        public int RideBonus { get; set; }

        public int MaxStep { get; set; }

        public List<Ride> Rides { get; set; }

        public List<Vehicle> Vehicles { get; set; }

        private List<Ride> AvailableRides { get; set; }

        public RouteManager()
        {
            Vehicles = new List<Vehicle>();
        }

        private void InitVehicles()
        {
            for (int i = 0; i < VehiclesCount; i++)
            {
                Vehicles.Add(new Vehicle
                {
                    Id = i,
                    CurrentPosition = new Point(),


                    Route = new Stack<Ride>()
                });
            }
        }

        public void EasyCalculation()
        {
            AvailableRides = Rides;
            InitVehicles();

            for(int i = 0; i < VehiclesCount && FindBestRides(Vehicles[i]); i++)
            {
                if(i == VehiclesCount -1)
                {
                    i = 0;
                }
            }
        }

        private bool FindBestRides(Vehicle vehicle)
        {
            

            AvailableRides = AvailableRides.Where(x => !x.IsPickedUp).ToList();

            if(AvailableRides.Count() <= 0 || AvailableRides.Min(x => x.GetDistance()) > Math.Abs(vehicle.CurrentSteps - MaxStep))
            {
                return false;
            }

            if(vehicle.CurrentSteps >= MaxStep)
            {
                return true;
            }

            //AvailableRides.OrderBy(x => x.GetDistance());
            //AvailableRides.Sort((x, y) => 
                                //(int)(GetWeightedValue(x, vehicle) - GetWeightedValue(y, vehicle)));
            var bestRide = FindMin(AvailableRides, vehicle);
            bestRide.IsPickedUp = true;
            vehicle.CurrentSteps += (bestRide.EarliestStart - vehicle.CurrentSteps) > 0 ? (bestRide.EarliestStart - vehicle.CurrentSteps) : 0;
            vehicle.CurrentSteps += bestRide.GetDistance();
            vehicle.Route.Push(bestRide);

            return true;                
        }

        private Ride FindMin(List<Ride> rides, Vehicle vehicle)
        {
            Ride minElement = null;

            foreach (var item in rides)
            {
                if(minElement == null || GetWeightedValue(minElement, vehicle) > GetWeightedValue(item, vehicle))
                {
                    minElement = item;
                }
            }

            return minElement;
        }

        private double GetWeightedValue(Ride r, Vehicle vehicle)
        {
            var bonus = (r.EarliestStart - vehicle.CurrentSteps) > 0 ? (r.EarliestStart - vehicle.CurrentSteps) : 0;
            return r.GetDistance() * 0.65 + vehicle.GetDistanceToRide(r) * 0.35 + bonus * 0.175;
        }
    }


}
